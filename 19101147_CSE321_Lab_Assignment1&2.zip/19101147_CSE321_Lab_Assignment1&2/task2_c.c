#include <stdio.h>
#include <string.h>

int main()
{
    char pass[200];
    int digits[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    char specialChar[] = {'$', '#', '_', '@'};
    
    int digitNo = 0, specialCharNo = 0;
    int lowerCase = 0, upperCase = 0;
    int error = 0;
    
    printf("Give password:\n");
    scanf("%s", &pass);

    int i, j;

    for(i = 0; pass[i] != '\0'; i++){

        if(pass[i] == '0' || pass[i] == '1' || pass[i] == '2' || pass[i] == '3' || 
        pass[i] == '4' || pass[i] == '5' || pass[i] == '6' || pass[i] == '7' || 
        pass[i] == '8' || pass[i] == '9'){
            
            digitNo += 1;
        }
        else if(pass[i] == '_' || pass[i] == '$' || pass[i] == '#' || pass[i] == '@'){
            
            specialCharNo += 1;    
        }
        else if(pass[i] >= 97 && pass[i] <= 122){
            
            lowerCase += 1;
        }
        else if(pass[i] >= 65 && pass[i] <= 90){
            
            upperCase += 1;
        }
    }    

    int catCounter = 0;
    if(digitNo == 0){
        printf("Digit missing");
        error += 1;
        catCounter += 1;
    }

    if(specialCharNo == 0){

        if(catCounter > 0)
            printf(", Special missing");
        else
            printf("Special missing");

        error += 1;
        catCounter += 1;
    }

    if(lowerCase == 0){
        
        if(catCounter > 0)
            printf(", Lowercase missing");
        else
            printf("Lowercase missing");

        error += 1;
        catCounter += 1;
    }

    if(upperCase == 0){

        if(catCounter > 0)
            printf(", Uppercase missing");
        else
            printf("Uppercase missing");

        error += 1;
        catCounter += 1;
    }

    if(error == 0){
        printf("OK");
    }

    return 0;
}