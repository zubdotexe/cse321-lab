#include <stdio.h>
#include <string.h>

int main()
{
    char string[200];

    printf("Give an input:\n");
    scanf("%s", &string);

    int length = strlen(string);
    char reversed_string[200];
    int i, j;
    j = 0;

    for(i = length - 1; i >= 0; i--){
        reversed_string[j] = string[i];
        j++;
    }

    if(strcmp(string, reversed_string) == 0){
        printf("Palindrome\n");
    }
    else{
        printf("Not Palindrome\n");
    }
    
    return 0;
}