#include<stdio.h>
#include <string.h>

int main() 
{
   char string[200];
   FILE * iFPointer, * oFPointer;

   iFPointer = fopen("inputFile.txt", "r");
   oFPointer = fopen("outputFile.txt", "w");

   while( !feof(iFPointer) ){
      
      fgets(string, 200, iFPointer);
      char * token = strtok(string, " ");

      while(token != NULL){
         
         printf("%s ", token);

         fprintf(oFPointer, "%s ", token);
         token = strtok(NULL, " ");
      }
      fprintf(oFPointer, "\n");

   }

   fclose(iFPointer);
   fclose(oFPointer);
   return 0;
}