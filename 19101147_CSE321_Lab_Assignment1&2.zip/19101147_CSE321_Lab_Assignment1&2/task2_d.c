#include <stdio.h>
#include <string.h>

int main() 
{
    char email[200];
    char newDomain[] = "sheba.xyz";
    
    printf("Please, enter your email address\n");
    scanf("%s", &email);
    
    char *token = strtok(email, "@");
    token = strtok(NULL, " ");
    
    if(strcmp(token, newDomain) == 0){
        printf("Email address is okay");
    }
    else
        printf("Email address is outdated");
    
    return 0;
}