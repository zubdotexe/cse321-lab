#include <stdio.h>

int subtract(int a, int b)
{
    int result = a - b;

    return result;
}

int add(int a, int b)
{
    int result = a + b;

    return result;
}

int multiply(int a, int b)
{
    int result = a * b;

    return result;
}

int main()
{

    int firstNumber, secondNumber;

    printf("Insert two numbers:\n");
    scanf("%d%d", &firstNumber, &secondNumber); 
    
    if (firstNumber > secondNumber)
    {
        int subtraction_result;
        subtraction_result = subtract(firstNumber, secondNumber);
        printf("The result is %d", subtraction_result); 
    }
    else if (firstNumber < secondNumber)
    {
        int addition_result;
        addition_result = add(firstNumber, secondNumber);
        printf("The result is %d", addition_result);
    }
    else if (firstNumber == secondNumber)
    {
        int multiplication_result;
        multiplication_result = multiply(firstNumber, secondNumber);
        printf("The result is %d", multiplication_result);
    }
    
    return 0;
}


