#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

int a = 0;
void *f1(void *ptr)
{
    char *message = (char *) ptr;
    int i;
    for(i = 0; i < 5; i++){
    	a += 1;
    	printf("Thread %s prints %d\n", message, a); 
    }
}

int main(int argc, char *argv[])
{
    pthread_t thread0, thread1, thread2, thread3, thread4;
    char *message0 = "0";
    char *message1 = "1";
    char *message2 = "2";
    char *message3 = "3";
    char *message4 = "4";
  
    int  iret0, iret1, iret2, iret3, iret4;
    
    iret0 = pthread_create(&thread0, NULL, f1, (void *) message0);
    sleep(1);  
    iret1 = pthread_create(&thread1, NULL, f1, (void *) message1);
    sleep(1);
    iret2 = pthread_create(&thread2, NULL, f1, (void *) message2);
    sleep(1);
    iret3 = pthread_create(&thread3, NULL, f1, (void *) message3);
    sleep(1);    
    iret4 = pthread_create(&thread4, NULL, f1, (void *) message4);
    
    pthread_join(thread0, NULL);
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);
    
    return 0;
}