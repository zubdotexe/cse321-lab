#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char *argv[]) 
{
    FILE *fpointer = fopen(argv[1], "w");
    char string[10];

    while(1){
        printf("Please, enter some string:\n");
        gets(string);
        
        if(strcmp(string, "-1") == 0)
            fprintf(fpointer, "%s\n", string);
        else
            break;
        
    }
    fclose(fpointer);
    return 0;
}
