#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

void *f1(void *ptr)
{
    char *message = (char *) ptr;
    printf("thread-%s running\n", message);
    printf("thread-%s closed\n", message);
}

int main(int argc, char *argv[])
{
    pthread_t thread1, thread2, thread3, thread4, thread5;
    char *message1 = "1";
    char *message2 = "2";
    char *message3 = "3";
    char *message4 = "4";
    char *message5 = "5";
  
    int iret1, iret2, iret3, iret4, iret5;
    
    iret1 = pthread_create(&thread1, NULL, f1, (void *) message1);
    sleep(1);
    iret2 = pthread_create(&thread2, NULL, f1, (void *) message2);
    sleep(1);
    iret3 = pthread_create(&thread3, NULL, f1, (void *) message3);
    sleep(1);    
    iret4 = pthread_create(&thread4, NULL, f1, (void *) message4);
    sleep(1);    
    iret5 = pthread_create(&thread5, NULL, f1, (void *) message5);
    
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);
    pthread_join(thread5, NULL);
    
    return 0;
}