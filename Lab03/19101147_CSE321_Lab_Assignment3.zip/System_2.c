#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() 
{
    pid_t pid1;
    pid1 = fork();

    if(pid1 == 0){
        pid_t pid2;
        pid2 = fork();
        
        if(pid2 == 0){
            printf("I am grand child\n");
        }
        else if(pid2 > 0){
            wait();
            printf("I am child\n");
        }
    }
    else if(pid1 > 0){
        wait();
        printf("I am parent\n");
    }
    
    return 0;
}