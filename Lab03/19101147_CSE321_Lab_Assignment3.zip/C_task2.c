#include <stdio.h>

int perfectNum(int a, int b)
{
    int i;
    for(i = a; i <= b; i++){
        int j;
        int sum = 0;
        for(j = 1; j <= i/2; j++){
            if(i % j == 0){
                sum += j;
            }
        }

        if(sum == i){
            printf("\n%d\n", i);
        }
    }
}

int main()
{
    int start, end;

    scanf("%d", &start);
    scanf("%d", &end);
    
    perfectNum(start, end);

    return 0;
}