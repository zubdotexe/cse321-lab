#include <stdio.h>

#include <sys/types.h>

#include <unistd.h>

#include <stdlib.h>



int main(int argc, char *argv[])

{

    int i, n;

    printf("Among the passed arguments: %d\n", argc);

    

    for(i = 0; i < argc; i++){

        n = atoi(argv[i]);



        if(n % 2 == 0){

            printf("The number %d is even.\n", n);

        }

        else{

            printf("The number %d is odd.\n", n);

        }

    }


    return 0;
    

}