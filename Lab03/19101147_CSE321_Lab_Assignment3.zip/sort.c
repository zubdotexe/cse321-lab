#include <stdio.h>

#include <stdlib.h>

#include <sys/types.h>

#include <unistd.h>



int main(int argc, char *argv[])

{

    int n, i, j;

    int arr[argc];

    printf("Passed arguments are: \n");



    for(i = 0; i < argc; i++){

        n = atoi(argv[i]);

        arr[i] = n;

        printf("%d ", n);

    }

    printf("\n\nSorted(descending) aruments are: \n");



    for(i = 0; i < argc; i++){

        for(j = i+1; j < argc; j++){

            

            if(arr[i] < arr[j]){

                int temp = arr[i];

                arr[i] = arr[j];

                arr[j] = temp;

            }

        }

    }

    

    for(i = 0; i < argc; i++){

        printf("%d\n", arr[i]);

    }

    

    return 0;

}