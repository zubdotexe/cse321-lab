#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv)
{
    printf("Parent process ID: %d\n", getpid());
    pid_t pid1 = fork();
    
    if(pid1 == 0){
        printf("Child process ID: %d\n", getpid());
        
        pid_t pid2, pid3;
        
        pid2 = fork();
        if(pid2 == 0){
            printf("Grand Child process ID: %d\n", getpid());
        }
        
        pid3 = fork();
        if(pid3 == 0){
            printf("Grand Child process ID: %d\n", getpid());
        }
    }
    
return 0;
}