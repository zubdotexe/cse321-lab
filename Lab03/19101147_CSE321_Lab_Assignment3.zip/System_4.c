#include <stdio.h>

#include <sys/types.h>

#include <unistd.h>



int main()

{

    pid_t pid = fork();



    if(pid == 0){

        execl("/home/zubdotexe/Desktop/CSE321/lab3/sort", "15", "7", "31", "43", NULL);

    }

    else if(pid > 0){

        wait();

        execl("/home/zubdotexe/Desktop/CSE321/lab3/oddeven", "21", "16", "71", "26", NULL);

    }



    return 0;

}