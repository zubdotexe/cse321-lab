#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>


int *sum1, *sum2, *sum3;
void *ascii_sum(void *letters)
{
    char *name = (char *) letters;
    int *addition = malloc(sizeof(int));
    int i, sum = 0;
    for(i = 0; i < strlen(name); i++){
        sum += name[i];
    }
    
    *addition = sum;
    return addition;
}

void *checker(void *val)
{
    if(*sum1 == *sum2 && *sum2 == *sum3){
    	printf("Youreka\n");
    }
    else if(*sum1 == *sum2 || *sum2 == *sum3 || *sum1 == *sum3){
    	printf("Miracle\n");
    }
    else if(*sum1 != *sum2 != *sum3){
    	printf("Hasta la vista\n");
    }
}

int main(int argc, char *argv[])
{   
    pthread_t thread1, thread2, thread3, thread4;
    
    char *name1 = "Kate";
    char *name2 = "Anna";
    char *name3 = "Henry";
    
    pthread_create(&thread1, NULL, ascii_sum, (void *)name1);
    pthread_create(&thread2, NULL, ascii_sum, (void *)name2);
    pthread_create(&thread3, NULL, ascii_sum, (void *)name3);
    
    pthread_join(thread1, (void *) &sum1);
    pthread_join(thread2, (void *) &sum2);
    pthread_join(thread3, (void *) &sum3);
    
    pthread_create(&thread4, NULL, checker, NULL);
    pthread_join(thread4, NULL);
    
    return 0;
}