#include <stdio.h>

struct paratha{
    int quantity;
    int unitPrice;
};

struct vegetable{
    int quantity;
    int unitPrice;
};

struct mineralWater{
    int quantity;
    int unitPrice;
};

int main()
{
    struct paratha p;
    struct vegetable v;
    struct mineralWater m;

    int totalPrice = 0, noOfPeople;
    float individualPayment;

    printf("Quantity Of Paratha: ");
    scanf("%d", &p.quantity);
    printf("Unit Price: ");
    scanf("%d", &p.unitPrice);

    totalPrice += (p.quantity * p.unitPrice);

    printf("Quantity Of Vegetable: ");
    scanf("%d", &v.quantity);
    printf("Unit Price: ");
    scanf("%d", &v.unitPrice);

    totalPrice += (v.quantity * v.unitPrice);

    printf("Quantity Of Mineral Water: ");
    scanf("%d", &m.quantity);
    printf("Unit Price: ");
    scanf("%d", &m.unitPrice);

    totalPrice += (m.quantity * m.unitPrice);

    printf("Number Of People: ");
    scanf("%d", &noOfPeople);

    individualPayment = totalPrice / noOfPeople;
    printf("Individual people will pay: %f tk", individualPayment);

    return 0;
}