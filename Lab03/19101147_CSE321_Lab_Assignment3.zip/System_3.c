#include <stdio.h>
#include <sys/types.h>

int count = 0;
int main() {
    
    count += 1;
    pid_t a, b, c;

    count += 1;
    a = fork();
    
    count += 1;
    b = fork();
    
    count += 1;
    c = fork();
    
    if(a % 2 != 0){
        count += 1;
    }
    
    if(b % 2 != 0){
        count += 1;
    }
    
    if(c % 2 != 0){
        count += 1;
    }
    
    wait();
    if(a != 0 && b != 0 && c != 0){
        printf("%d\n", count);
    }
    return 0;
}