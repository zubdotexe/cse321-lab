/* This example is rewritten based on the example from */
/* <http://www.coe.uncc.edu/~abw/parallel/pthreads/pthreads.html */
/* It illustrates the idea of shared memory programming */
/* oct-03-2000 */

#include <pthread.h>   
#include <stdio.h>
#define MAX 10
#define BUFLEN 6
#define MAX_COUNT 15
#define NUMTHREAD 2      /* number of threads */

void * consumer(int *id);
void * producer(int *id);

char buffer[BUFLEN];
char source[BUFLEN];
int cCount = 0;
int pCount = 0;
int buflen;
pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t nonEmpty  = PTHREAD_COND_INITIALIZER;
pthread_cond_t full  = PTHREAD_COND_INITIALIZER;
int thread_id[NUMTHREAD]  = {0,1};
int i = 0, j = 0;

main()
{
  int i;
  /* define the type to be pthread */
  pthread_t thread[NUMTHREAD];

  strcpy(source,"abcdef");
  buflen = strlen(source);
  /* create 2 threads*/
  /*
    pthread_create(&thread[2], NULL, (void *)watch, &thread_id[2]);
  */
  /* create one consumer and one producer */
  pthread_create(&thread[1], NULL, (void *)producer, &thread_id[0]);
  pthread_create(&thread[0], NULL, (void *)consumer, &thread_id[1]);
  
  
  for(i=0; i< NUMTHREAD ; i++)
    {
      pthread_join(thread[i], NULL);
    }
}

void * consumer(int *id)
{
  /* lock the variable */
  pthread_mutex_lock(&count_mutex);

  while(j < MAX)
    {
      /* wait for the buffer to have something in it */
      pthread_cond_wait(&nonEmpty, &count_mutex);

      /* take the char from the buffer and increment the cCount */
      printf("%d consumed %c by Thread %d\n",j, buffer[cCount], *id);
      cCount = (cCount + 1) % BUFLEN;
      fflush(stdout);
      j ++;

      if (j < (MAX - 2))     
	/* Last sleep might leave the condition un-processed.
	 * So we prohibit sleep towards the end
	 */
	if (rand()%6 < 1)
	  sleep(rand()%3);

    }
  /* signal the producer that the buffer has been consumed */
  /* pthread_cond_signal(&full);*/
  /*unlock the variable*/
  pthread_mutex_unlock(&count_mutex);
}

void * producer(int *id)
{

  while (i < MAX)
    {
      /* lock the variable */
      pthread_mutex_lock(&count_mutex);
      /* wait for the buffer to have space */
      /* pthread_cond_wait(&full, &count_mutex);*/
      strcpy(buffer,"");
      buffer[pCount] = source[pCount%buflen];
      printf("%d produced %c by Thread %d\n",i, buffer[pCount], *id);
      fflush(stdout);
      pCount = (pCount + 1) % BUFLEN;
      i ++;
      /* for the condition notify the thread */
      pthread_cond_signal(&nonEmpty);
      /*unlock the variable*/
      pthread_mutex_unlock(&count_mutex);

      if (i < (MAX - 2))     
	/* Last sleep might leave the condition un-processed.
	 * So we prohibit sleep towards the end
	 */
	if (rand()%6 >= 1)
	  sleep(rand()%3);

    }
}