#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>

/* producere consumer problem */

#define maxCrops 5 // 5 threads
#define warehouseSize 5 // size of the buffer which stores items
    
sem_t empty;
sem_t full;
int in = 0;
int out = 0;
char crops[warehouseSize]={'R','W','P','S','M'};//indicatig room for different crops
char warehouse[warehouseSize]={'N','N','N','N','N'};//initially all the room is empty
pthread_mutex_t mutex;
int buffer[warehouseSize];
    
void *producer(void *fno)
{
    int item;
    for(int i = 0; i < maxCrops; i++)
    {
        item = rand() % 5; // storing a random var
        sem_wait(&empty);
        pthread_mutex_lock(&mutex); // initializing mutex
        // buffer[in] = item;
        
        warehouse[item] = crops[item];
        in = item;
        printf("Farmer %d: Insert crops %c at %d\n", *((int *) fno), crops[item], item);
        in = (in + 1) % warehouseSize;
        pthread_mutex_unlock(&mutex);
        sem_post(&full);
    }
    printf("Farmer %d: ", *((int *) fno));
    for(int i = 0; i < warehouseSize; i++)
    {
        printf("%c", warehouse[i]);
    }
    printf("\n");
}

void *consumer(void *sho)
{
    int item;
    for(int i = 0; i < maxCrops; i++)
    {   
        item = rand() % 5;
        sem_wait(&full);
        pthread_mutex_lock(&mutex);
        warehouse[item] = 'N';
        out = item;
        printf("Shop owner %d: Remove crops %c from %d\n", *((int *) sho), crops[item], item);
        out = (out + 1) % warehouseSize;
        pthread_mutex_unlock(&mutex);
        sem_post(&empty);
    }
    printf("ShopOwner %d: ", *((int *) sho));
    for(int i = 0; i < warehouseSize; i++)
    {
        printf("%c", warehouse[i]);
    }
    printf("\n");
}

int main()
{
    pthread_t pro[5], con[5];
    pthread_mutex_init(&mutex, NULL); // initializing mutex
    /*
    sem_init(&sem, pshared, value)
    If the value of pshared is zero, then the semaphore cannot be shared between processes. If 
    the value of pshared is nonzero, then the semaphore can be shared between processes.
    */
    sem_init(&empty, 0, warehouseSize); // initializing semaphore
    sem_init(&full, 0, 0); // initializing semaphore
    
    int a[5] = {1, 2, 3, 4, 5}; // for numbering the pro and con
    
    for(int i = 0; i < 5; i++)
    {
        pthread_create(&pro[i], NULL, (void *)producer, (void *)&a[i]);
    }
    for(int i = 0; i < 5; i++)
    {
        pthread_create(&con[i], NULL, (void *)consumer, (void *)&a[i]);
    }
    for(int i = 0; i < 5; i++)
    {
        pthread_join(pro[i], NULL);
    }
    for(int i = 0; i < 5; i++)
    {
        pthread_join(con[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);

    return 0;
}