#include <stdio.h>
#include <limits.h>
#include <stdbool.h> //for bool data types
#include <stdlib.h>  //for qsort

struct process
{
    int pid;
    int arrivalTime;
    int burstTime;
    int startTime;
    int completionTime;
    int turnaroundTime;
    int waitingTime;
    int burstTimeRemaining;
}ps[100];

int main()
{

    int n, index, timeQuantum;

    bool visited[100] = {false};
    int currentTime = 0;
    int completed = 0;

    printf("Enter total number of processes: ");
    scanf("%d", &n);
    int queue[100], startIndex = -1, endIndex = -1;

    for(int i = 0; i < n; i++)
    {
        ps[i].arrivalTime = 0;
        ps[i].pid = i + 1;
    }

    for(int i = 0; i < n; i++)
    {
        printf("\nEnter the burst time for process %d: ", (i + 1));
        scanf("%d", &ps[i].burstTime);
        ps[i].burstTimeRemaining = ps[i].burstTime;
    }

    printf("\nEnter time quantum: ");
    scanf("%d", &timeQuantum);
    printf("\n");

    startIndex = endIndex = 0;
    queue[endIndex] = 0;
    visited[0] = true;

    while(completed != n)
    {
        index = queue[startIndex];
        startIndex++;

        if(ps[index].burstTimeRemaining == ps[index].burstTime)
        {
            ps[index].startTime = currentTime;
            currentTime = ps[index].startTime;
        }

        if(ps[index].burstTimeRemaining > timeQuantum)
        {
            ps[index].burstTimeRemaining -= timeQuantum;
            currentTime += timeQuantum;
        }
        else
        {
            currentTime += ps[index].burstTimeRemaining;
            ps[index].burstTimeRemaining = 0;
            completed++;

            ps[index].completionTime = currentTime;
            ps[index].turnaroundTime = ps[index].completionTime - ps[index].arrivalTime;
            ps[index].waitingTime = ps[index].turnaroundTime - ps[index].burstTime;
        }

        // checking which new processes need to be pushed to ready queue from input list
        for(int i = 1; i < n; i++)
        {
            if(ps[i].burstTimeRemaining > 0 && visited[i] == false)
            {
                queue[++endIndex] = i;
                visited[i] = true;
            }
        }
        // checking if process on CPU needs to be pushed to ready queue
        if(ps[index].burstTimeRemaining > 0)
            queue[++endIndex] = index;
    } 
    // for printing the output
    printf("Process \t\tCompletion Time\t\tTurnaround Time\t\tWaiting Time\n");
    for(int i = 0; i < n; i++)
        printf("%d\t\t\t%d\t\t\t%d\t\t\t%d\n", (i + 1), ps[i].completionTime, ps[i].turnaroundTime, ps[i].waitingTime);

    return 0;
}