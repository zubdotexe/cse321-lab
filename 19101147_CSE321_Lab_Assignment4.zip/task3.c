# include <stdio.h>
# include <stdbool.h> // for bool data types
# include <limits.h>

struct process
{
    int pid;
    int arrivalTime;
    int burstTime;
    int priority;
    int startTime;
    int completionTime;
    int turnaroundTime;
    int waitingTime;
}ps[100];

int main()
{
    int n;
    float burstTimeRemaining[100];
    bool isCompleted[100] = {false};
    int currentTime = 0;
    int completed = 0;   

    printf("Enter number of  processes: ");
    scanf("%d", &n);

    for(int i = 0; i < n; i++)
    {
        printf("\nEnter the arrival time for process %d: ", (i + 1));
        scanf("%d", &ps[i].arrivalTime);
        ps[i].pid = i + 1;

        printf("Enter the burst time for process %d: ", (i  + 1));
        scanf("%d", &ps[i].burstTime);
        burstTimeRemaining[i] = ps[i].burstTime;

        printf("Enter the priority for process %d: ", (i  + 1));
        scanf("%d", &ps[i].priority);
    }
    printf("\n");

    while(completed != n)
    {
        int minimum = INT_MAX;
        int  minimumIndex = -1;

        for(int i = 0; i < n; i++)
        {
            if(ps[i].arrivalTime <= currentTime && isCompleted[i] == false)
            {
                if(ps[i].priority < minimum)
                {
                    minimum = ps[i].priority;
                    minimumIndex = i;
                }              
                if(ps[i].priority == minimum)
                {
                    if(ps[i].arrivalTime < ps[minimumIndex].arrivalTime)
                    {
                        minimum = ps[i].priority;
                        minimumIndex = i;
                    }
                }  
            }
        }

        if(minimumIndex == -1)
        {
            currentTime++;
        }
        else
        {
            if(burstTimeRemaining[minimumIndex] == ps[minimumIndex].burstTime)
            {
                ps[minimumIndex].startTime = currentTime;
            }

            burstTimeRemaining[minimumIndex] -= 1;
            currentTime++;

            if(burstTimeRemaining[minimumIndex] == 0)
            {
                ps[minimumIndex].completionTime = currentTime;
                ps[minimumIndex].turnaroundTime = ps[minimumIndex].completionTime - ps[minimumIndex].arrivalTime;
                ps[minimumIndex].waitingTime = ps[minimumIndex].turnaroundTime - ps[minimumIndex].burstTime;

                completed++;
                isCompleted[minimumIndex] = true;
            }
        }
    }
    // for printing the values
    printf("Process \t\tCompletion Time\t\tTurnaround Time\t\tWaiting Time\n");
    for(int i = 0; i < n; i++)
        printf("%d\t\t\t%d\t\t\t%d\t\t\t%d\n", (i + 1), ps[i].completionTime, ps[i].turnaroundTime, ps[i].waitingTime);
    return 0;
}

